# Automatyzacja Spingo
Framework jest wykonany w celu testowania produktu Spingo, nie jest przystosowana do testowania innych produktów. 

## Metodyka
Autommatyzacja spingo została w głównej mierze wykonana przy użyciu:
* Python
* Selenium
* Pytest
* Unittest
* DDT
* Request
* Webdriver-manager

## Dokumentacja do Automatyzacji
Testy wykonywane są na bazie Pytest, więc muszą być wykonywane zgodnie z zasadami panującymi w tej bibliotece.
Framework jest stworzony obiektowo przede wszystkim, w celu lepszej integracji z zewnętrznymi bibliotekami.

#### <sub>/testcases</sub> 
Głównymi plikami wywołującymi funkcje są te zaczynające się słowem test oraz znajdujące się w folderze <sup>/testcases</sup> 
We wcześniej wspomnianym folderze <sup>/testcases</sup> znajdziemy także plik <sup>/conftest</sup> który dostarcza pytest
fixtures które przekazują informacje o driver, jego ustawieniach oraz tworzeniu raportów z testów. 

#### <sub>/utilities</sub> 
Pliki dostarczające wszelkie utilities które nie zawierają w sobie driver'a są dostarczane w folderze <sup>/utilities</sup> 
Znajdują się tu klasa zawierająca funkcje takie jak obsługa przeglądarki, funkcja logowania, czy chociażby assercje.

#### <sub>/reports</sub> 
Tutaj znajdziemy dane po wykonaniu testów. znajduje się tu plik <sup>log.log</sup> który zawiera logi zapisywane w trakcie działania
testów, zarówno  jak i folder <sup>/html_reports</sup> w którym znajdziemy raporty .html z testów.

#### <sub>/pages</sub> 
W folderze pages znajdują się pliki które mają na celu określić lokatory pól stron odpowiednich do ich nazw, a następnie je selectować
i wykonać na nich odpowiednie działania.

#### <sub>/config_files</sub> 
Tutaj znajdziemy pliki konfiguracyjne.

#### <sub>/base</sub> 
Funkcje obsługujące przeglądarkę zawierające driver'a są dostarczane w folderze <sup>/base</sup> 
Znajduje się tu klasa obsługująca takie funkcje jak: scroll, powrót do poprzedniej strony oraz selecty i selecty z waitami.

#### <sub>/tools</sub> 
Folder <sup>/tools</sup> zawiera:
* request do API.
* generatory: dokumentów tozasmości, numerów telefonu, numeru pesel
* Test data - funkcje obsługujące pliki .xlsx. Moduł ***DDT*** który został tu zastosowany wraz z modułem ***unpack*** przypisują dane
relatywnie do ilości argumentów funkcji.
* Database log extractor - do wyciągania logów z bazy danych 

## Argumenty uzywane do inicjalizacji testów
<sup>***-v --color=yes***</sup>

#### Gdzie:
* __-v__ - oznacza ***verbose i służy do obsługi większej ilości informacji w output***
* __--color__ - oznacza ***Wymusza na pytest drukowanie output w kolorze***
