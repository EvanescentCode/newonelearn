import hashlib
import crc
import struct

test_url_1 = 'https://test2.falcon.nest.corp/FMBewnioseknew/WizardWfB.aspx?b=1&p=2&s=920&l=Faktoria&Field1=xxx'
test_url_2 = 'https://test2.falcon.nest.corp/FMBewnioseknew/WizardWfB.aspx?b=1&p=2&s=920&l=Faktoria&Field1=xxx&Field2=yyy'

preprod_url_1 = 'https://test1.falcon.nest.corp/FMBewnioseknew/WizardWfB.aspx?b=1&p=2&s=422&l=Faktoria&Field1=xxx'
preprod_url_2 = 'https://test1.falcon.nest.corp/FMBewnioseknew/WizardWfB.aspx?b=1&p=2&s=422&l=Faktoria&Field1=xxx&Field2=yyy'

prod_url_1 = 'https://wniosek.faktoria.pl/fmbewnioseknew/WizardWfB.aspx?b=1&p=2&s=355&l=Faktoria&Field1=xxx'
prod_url_2 = 'https://wniosek.nestbank.pl/fmbewnioseknew/WizardWfB.aspx?b=1&p=2&s=355&l=Faktoria&Field1=xxx&Field2=yyy'
prod_url = 'https://wnioski.nestbank.pl/FMBewnioseknew/WizardWfB.aspx?b=1&p=2&s=355&l=Faktoria&Field1=4eae35f1b35977a00ebd8086c259d4c9&bankId=1&profileId=2&c=1'


class ADDLinkGen:

    def __init__(self, env, intercessor, nip=None, id_offer=None):
        self.env = env
        self.intercessor = intercessor
        self.nip = nip
        self.id_offer = id_offer
        self.url_changed = None
        self.main(env, intercessor)

    def main(self, nip=None, id_offer=None):
        if self.env == 'test':
            if self.intercessor == 'e-commerce':
                self.__zencode_url(test_url_1, self.intercessor, nip, id_offer)
            elif self.intercessor == 'intercessor':
                self.__zencode_url(test_url_2, self.intercessor, nip, id_offer)
        elif self.env == 'preprod':
            if self.intercessor == 'e-commerce':
                self.__zencode_url(test_url_1, self.intercessor, nip, id_offer)
            elif self.intercessor == 'intercessor':
                self.__zencode_url(test_url_2, self.intercessor, nip, id_offer)
        elif self.env == 'prod':
            if self.intercessor == 'e-commerce':
                self.__zencode_url(test_url_1, self.intercessor, nip, id_offer)
            elif self.intercessor == 'intercessor':
                self.__zencode_url(test_url_2, self.intercessor, nip, id_offer)

    def __zencode_url(self, url, intercessor, nip=None, id_offer=None):
        if intercessor == 'e-commerce':
            # static
            ecommerce_input_1 = 'www'
            # encode
            ecomerce_bytes = ecommerce_input_1.encode('utf-8')
            ecommerce_hash = hashlib.md5(ecomerce_bytes)
            hashed_hexi = ecommerce_hash.hexdigest()
            # url
            url = f'{url}'
            self.url_changed = url.replace('xxx', hashed_hexi)
        elif self.intercessor == 'intercessor':
            # NIP input
            posrednik_input_1 = nip
            # encode
            posrednik_bytes = posrednik_input_1.encode('utf-8')
            posrednik_hash = hashlib.md5(posrednik_bytes)
            hashed_hexi = posrednik_hash.hexdigest()
            # ID offer
            posrednik_input_2 = id_offer
            posrednik_input_2_hash = posrednik_input_2.encode('utf-8')
            posrednik_input_2_hashed = self.__crc32_struct(posrednik_input_2_hash)
            # url
            url = f'{url}'
            self.url_changed = url.replace('xxx', hashed_hexi).replace('yyy', str(posrednik_input_2_hashed))
        return print(self.url_changed)

    def __crc32_struct(self, data):
        def swap32(i):
            return struct.unpack("<I", struct.pack(">I", i))[0]

        calculator = crc.Calculator(crc.Crc32.BZIP2, optimized=True)
        effect = (format(swap32(calculator.checksum(data)) & 0xffffffff, '08x'))
        return effect


ADDLinkGen('test', 'e-commerce')
