import logging
import requests
import json
import random
from dataclasses import dataclass

from Automatyzacja.utilities.page import Utils


@dataclass
class DataClass:
    contract_id: str
    merchant_id: str


class SendRequest:
    """
    Klasa odpowiadająca za wysyłanie zapytania do API i uzyskiwania odpowiedzi.
    Funkcje get_applicationNumber oraz get_fieldinfos zwracają kolejno FKT number, oraz URL
    z Request.
    """

    def __init__(self, url=None, number=None):
        self.field_infos = None
        self.application_number = None
        self.url = url
        self.number = number

    def headers(self):
        headers = {
            "Ocp-Apim-Subscription-Key": "fe85d2bc78cc462eb87195b00d31eb04",
            "Content-Type": "application/json"
        }
        return headers

    def default_url(self):
        url = 'https://api2.test2.nest.corp/faktoria/fpay/Submit2'
        return url

    def post_request(self, env):
        data = self.data_to_request(env)
        json_data = json.dumps(data)
        response = requests.post(self.url, data=json_data, headers=self.headers(), verify=False)
        return response

    def data_to_request(self, env: str) -> dict:
        if env == '14za0':
            data = {
                "contractId": "ADD276431688",
                "merchantId": "9512389299",
                "brokerId": "",
                "transactionId": "",
                "currency": "PLN",
                "amount": 5000,
                "buyerId": "",
                "urlNotify": "https://webhook.site/b2a22fc2-e127-45a2-b8e4-26b40bdcce72",
                "toSendNotify": True,
                "urlCancel": "https://faktoria.pl",
                "urlReturn": "https://spingo.pl",
                "maxAppTime": 60,
                "ip": "255.255.255.255",
                "orderId": "12345123451234512345",
                "splitPayment": False,
                "vatAmount": 112.2,
                "vatAmountPln": 112.2
            }
        elif env == 'limit':
            data = {
                "contractId": "ADD314144459",
                "merchantId": "7772701025",
                "brokerId": "",
                "transactionId": "",
                "currency": "PLN",
                "amount": 0,
                "buyerId": "",
                "urlNotify": "https://webhook.site/79b46fc2-f2cd-4c36-9640-e1fda62523e3",
                "toSendNotify": True,
                "urlCancel": "https://faktoria.pl",
                "urlReturn": "https://spingo.pl",
                "maxAppTime": 60,
                "ip": "255.255.255.255",
                "orderId": "12345123451234512345",
                "splitPayment": False,
                "vatAmount": 112.2,
                "vatAmountPln": 112.2
            }
        elif env == 'pozyczka':
            data = {
                "contractId": "ADD596196166",
                "merchantId": "5423050120",
                "brokerId": "",
                "transactionId": "",
                "currency": "PLN",
                "amount": 6000,
                "buyerId": "",
                "urlNotify": "https://webhook.site/79b46fc2-f2cd-4c36-9640-e1fda62523e3",
                "toSendNotify": True,
                "urlCancel": "https://faktoria.pl",
                "urlReturn": "https://spingo.pl",
                "maxAppTime": 60,
                "ip": "255.255.255.255",
                "orderId": "12345123451234512345",
                "splitPayment": False,
                "vatAmount": 112.2,
                "vatAmountPln": 112.2
            }
        elif env == 'standard':
            data = {
                "contractId": "FKT688957860",
                "merchantId": "7262543047",
                "brokerId": "",
                "transactionId": "",
                "currency": "PLN",
                "amount": 6000,
                "buyerId": "",
                "urlNotify": "https://webhook.site/79b46fc2-f2cd-4c36-9640-e1fda62523e3",
                "toSendNotify": True,
                "urlCancel": "https://faktoria.pl",
                "urlReturn": "https://spingo.pl",
                "maxAppTime": 60,
                "ip": "255.255.255.255",
                "orderId": "12345123451234512345",
                "splitPayment": False,
                "vatAmount": 112.2,
                "vatAmountPln": 112.2
            }
        else:
            raise Exception("Incorrectly implemented data")

        numbers = random.randint(10000, 99999)
        self.number = f"FV/{numbers}/20"
        data["transactionId"] = self.number
        return data

    def extract_data(self, data):
        application_number = data['applicationNumber']
        field_infos = data['fieldInfos'][0].split(',')[0]
        return application_number, field_infos

    def send_request(self, env: str):
        if self.url is None:
            self.url = self.default_url()
        response = self.post_request(env)
        response_data = response.json()
        if isinstance(response_data, dict):
            self.application_number, self.field_infos = self.extract_data(response_data)
        return self.field_infos

    def get_field_infos(self):
        return self.field_infos

    def get_application_number(self):
        return self.application_number
