class SmsCodeExtractor:
    @staticmethod
    def execute_query(element_text, server, database):
        connection_string = f"DRIVER={{ODBC Driver 17 for SQL Server}};SERVER={server};DATABASE={database};Trusted_Connection=yes"
        query = f"""
            SELECT A.ProductFields.value('ApplicationProductFields[1]/string[1]/field[@name="T_WYGENEROWANY_PIN"][1]', 'nvarchar(10)') AS "PIN"
            FROM [FerrytFMBMain].[dbo].[Application] A WITH (NOLOCK)
            WHERE A.[ApplicationNumber] = '{element_text}'
        """
