import pyodbc
from datetime import datetime
import logging
from Automatyzacja.utilities.page import Utils

# Dictionaries containing fields for mapping the output from database
dane = {
    'Serwer': 'Serwer',
    'Czas wywołania': 'Czas wywołania',
    'Numer wniosku': 'Numer wniosku',
}

field_labels = {
    'Status wniosku': 'Status wniosku',
    'Pierwszy Kod odmowy': 'Kod odmowy',
    'Drugi Kod odmowy': 'Drugi Kod odmowy',
    'Trzeci Kod odmowy': 'Trzeci Kod odmowy',
    'Kod bledu API': 'Kod odmowy API',
    'Opis bledu API': 'Opis odmowy API',
    'Powód odrzutu': 'Powód odrzutu',
    'Opis odrzutu': 'Opis odrzutu',
    'Ekran koncowy': 'Ekran koncowy',
}

log = Utils().custom_logger(log_level=logging.DEBUG)


# Current datetime
def __get_current_time():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


# Used servers
def __execute_and_print_query(application_numbers):
    servers = ['fer-db-t2-1', 'fer-db-t1-1']
    databases = ['FerrytFMBMain', 'FerrytFMBMainArch']

    for application_number in application_numbers:
        for server in servers:
            for database in databases:
                # Creation of connection string
                connection_string = f"DRIVER={{ODBC Driver 17 for SQL Server}};SERVER={server};DATABASE={database};Trusted_Connection=yes"

                # Making a connection to the database
                conn = pyodbc.connect(connection_string)

                # Cursor creation
                cursor = conn.cursor()
                query_spingo = f"""
                    SELECT
                    [Status wniosku],
                    CASE
                        WHEN LEFT([Kod odmowy 1], 1) = 's' THEN SUBSTRING([Kod odmowy 1], 2, LEN([Kod odmowy 1]))
                        ELSE [Kod odmowy 1]
                    END + ',' + CASE
                        WHEN LEFT([Kod odmowy treść 1], 1) = 's' THEN SUBSTRING([Kod odmowy treść 1], 2, LEN([Kod odmowy treść 1]))
                        ELSE [Kod odmowy treść 1]
                    END + ',' + CASE
                        WHEN LEFT([Typ odmowy 1], 1) = 's' THEN SUBSTRING([Typ odmowy 1], 2, LEN([Typ odmowy 1]))
                        ELSE [Typ odmowy 1]
                    END AS [Pierwszy kod odmowy],
                    CASE
                        WHEN LEFT([Kod odmowy 2], 1) = 's' THEN SUBSTRING([Kod odmowy 2], 2, LEN([Kod odmowy 2]))
                        ELSE [Kod odmowy 2]
                    END + ',' + CASE
                        WHEN LEFT([Kod odmowy treść 2], 1) = 's' THEN SUBSTRING([Kod odmowy treść 2], 2, LEN([Kod odmowy treść 2]))
                        ELSE [Kod odmowy treść 2]
                    END + ',' + CASE
                        WHEN LEFT([Typ odmowy 2], 1) = 's' THEN SUBSTRING([Typ odmowy 2], 2, LEN([Typ odmowy 2]))
                        ELSE [Typ odmowy 2]
                    END AS [Drugi kod odmowy],
                    CASE
                        WHEN LEFT([Kod odmowy 3], 1) = 's' THEN SUBSTRING([Kod odmowy 3], 2, LEN([Kod odmowy 3]))
                        ELSE [Kod odmowy 3]
                    END + ',' + CASE
                        WHEN LEFT([Kod odmowy treść 3], 1) = 's' THEN SUBSTRING([Kod odmowy treść 3], 2, LEN([Kod odmowy treść 3]))
                        ELSE [Kod odmowy treść 3]
                    END + ',' + CASE
                        WHEN LEFT([Typ odmowy 3], 1) = 's' THEN SUBSTRING([Typ odmowy 3], 2, LEN([Typ odmowy 3]))
                        ELSE [Typ odmowy 3]
                    END AS [Trzeci kod odmowy],
                    CASE
                        WHEN LEFT([Kod bledu API], 1) = 's' THEN SUBSTRING([Kod bledu API], 2, LEN([Kod bledu API]))
                        ELSE [Kod bledu API]
                    END AS [Kod bledu API],
                    CASE
                        WHEN LEFT([Opis bledu API], 1) = 's' THEN SUBSTRING([Opis bledu API], 2, LEN([Opis bledu API]))
                        ELSE [Opis bledu API]
                    END AS [Opis bledu API],
                    CASE
                        WHEN LEFT([Powód odrzutu], 1) = 's' THEN SUBSTRING([Powód odrzutu], 2, LEN([Powód odrzutu]))
                        ELSE [Powód odrzutu]
                    END AS [Powód odrzutu],
                    CASE
                        WHEN LEFT([Opis odrzutu], 1) = 's' THEN SUBSTRING([Opis odrzutu], 2, LEN([Opis odrzutu]))
                        ELSE [Opis odrzutu]
                    END AS [Opis odrzutu],
                    CASE
                        WHEN LEFT([Ekran koncowy], 1) = 's' THEN SUBSTRING([Ekran koncowy], 2, LEN([Ekran koncowy]))
                        ELSE [Ekran koncowy]
                    END AS [Ekran koncowy]
                FROM (
                    SELECT
                        ProductFields.value('(ApplicationProductFields[1]/complex[1]/field[@name="FKT_FPAY_KODY_ODM"]/fv/t.0/KOD_ODMOWY)[1]', 'nvarchar(15)') AS [Kod odmowy 1],
                        ProductFields.value('(ApplicationProductFields[1]/complex[1]/field[@name="FKT_FPAY_KODY_ODM"]/fv/t.0/KOD_ODMOWY_TRESC)[1]', 'nvarchar(max)') AS [Kod odmowy treść 1],
                        ProductFields.value('(ApplicationProductFields[1]/complex[1]/field[@name="FKT_FPAY_KODY_ODM"]/fv/t.0/TYP_ODRZUTU)[1]', 'nvarchar(15)') AS [Typ odmowy 1],
                        ProductFields.value('(ApplicationProductFields[1]/complex[1]/field[@name="FKT_FPAY_KODY_ODM"]/fv/t.1/KOD_ODMOWY)[1]', 'nvarchar(15)') AS [Kod odmowy 2],
                        ProductFields.value('(ApplicationProductFields[1]/complex[1]/field[@name="FKT_FPAY_KODY_ODM"]/fv/t.1/KOD_ODMOWY_TRESC)[1]', 'nvarchar(max)') AS [Kod odmowy treść 2],
                        ProductFields.value('(ApplicationProductFields[1]/complex[1]/field[@name="FKT_FPAY_KODY_ODM"]/fv/t.1/TYP_ODRZUTU)[1]', 'nvarchar(15)') AS [Typ odmowy 2],
                        ProductFields.value('(ApplicationProductFields[1]/complex[1]/field[@name="FKT_FPAY_KODY_ODM"]/fv/t.2/KOD_ODMOWY)[1]', 'nvarchar(15)') AS [Kod odmowy 3],
                        ProductFields.value('(ApplicationProductFields[1]/complex[1]/field[@name="FKT_FPAY_KODY_ODM"]/fv/t.2/KOD_ODMOWY_TRESC)[1]', 'nvarchar(max)') AS [Kod odmowy treść 3],
                        ProductFields.value('(ApplicationProductFields[1]/complex[1]/field[@name="FKT_FPAY_KODY_ODM"]/fv/t.2/TYP_ODRZUTU)[1]', 'nvarchar(15)') AS [Typ odmowy 3],
                        ProductFields.value('(ApplicationProductFields[1]/complex[1]/field[@name="FKT_FPAY_OBSLUGA_SERWISOW"]/fv/t.0/KOD_BLEDU)[1]', 'nvarchar(max)') AS [Kod bledu API],
                        ProductFields.value('(ApplicationProductFields[1]/complex[1]/field[@name="FKT_FPAY_OBSLUGA_SERWISOW"]/fv/t.0/OPIS_BLEDU)[1]', 'nvarchar(max)') AS [Opis bledu API],
                        ApplicationStatusSymbol AS [Status wniosku],
                        ProductFields.value('(ApplicationProductFields[1]/complex[1]/field[@name="FKT_POWOD_ODRZUTU"]/fv/t.0/POWOD_ODRZUTU)[1]', 'nvarchar(max)') AS [Powód odrzutu],
                        ProductFields.value('(ApplicationProductFields[1]/complex[1]/field[@name="FKT_POWOD_ODRZUTU"]/fv/t.0/OPIS_ODRZUTU)[1]', 'nvarchar(max)') AS [Opis odrzutu],
                        ProductFields.value('(ApplicationProductFields[1]/string[1]/field[@name="FKT_FPAY_EKRAN_KONCOWY"])[1]', 'nvarchar(max)') AS [Ekran koncowy]
                    FROM [{database}].[dbo].[Application]
                    WHERE ApplicationNumber = '{application_number}'
                ) AS Subquery;
                """

                # Request
                cursor.execute(query_spingo)

                # Download the request response
                results = cursor.fetchall()

                # If results have been found save them into a log file
                if results:
                    log.info("-----")
                    log.info(f"Serwer: {server}")
                    log.info(f"Czas wywołania: {__get_current_time()}")
                    log.info(f"Numer wniosku: {application_number}")
                    # Creation of list key:value
                    labeled_rows = [(field_labels[label], value if value is not None else "") for label, value in zip(field_labels, results[0])]
                    # Output of values to log file
                    for label, value in labeled_rows:
                        if len(value) > 1:
                            if label == "Kod odmowy" or "Drugi Kod odmowy" or "Trzeci Kod odmowy":
                                odm = value.split(',')
                                for i in odm:
                                    log.info(f"{label}: {i}")
                            else:
                                log.info(f"{label}: {value}")
                    log.info("-----")

                # Disable the connection
                conn.close()


def db_extractor_main(application_numbers: str):
    application_numbers = application_numbers
    application_numbers = [num.strip() for num in application_numbers.split(',') if num.strip()]
    __execute_and_print_query(application_numbers)




