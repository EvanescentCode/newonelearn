import random


class IDGenerator:
    """
    Klasa odpowiada za generowanie danych dokumentu tożsamości w Polsce.
    Została stworzona, tak, aby przechodziła wszystkie walidacje.
    Funkcja oblicz_sume_i_sprawdz_autentycznosc jest swego rodzaju walidacją sprawdzającą,
    czy na pewno wygenerowany numer dokumetu tożsamości jest prawidłowy w świetle weryfikacji.
    """

    def __init__(self, id_number=None):
        self.id_number = id_number

    def __verify_auth(self):
        numbers_dict = {
            "A": 10, "B": 11, "C": 12, "D": 13, "E": 14, "F": 15, "G": 16, "H": 17, "I": 18, "J": 19,
            "K": 20, "L": 21, "M": 22, "N": 23, "O": 24, "P": 25, "Q": 26, "R": 27, "S": 28, "T": 29,
            "U": 30, "V": 31, "W": 32, "X": 33, "Y": 34, "Z": 35
        }
        weights = [7, 3, 1, 9, 7, 3, 1, 7, 3, 1, 7, 3, 1, 7, 3, 1, 7, 3, 1, 7, 3, 1, 7, 3, 1, 7, 3, 1]

        sum_number = 0
        for i in range(len(self.id_number)):
            digit = self.id_number[i]
            if digit.isalpha():
                sum_number += numbers_dict[digit] * weights[i]
            elif digit.isdigit():
                sum_number += int(digit) * weights[i]

        return sum_number % 10 == 0

    def generate_id(self):
        numbers_dict = {
            10: "A", 11: "B", 12: "C", 13: "D", 14: "E", 15: "F", 16: "G", 17: "H", 18: "I", 19: "J",
            20: "K", 21: "L", 22: "M", 23: "N", 24: "O", 25: "P", 26: "Q", 27: "R", 28: "S", 29: "T",
            30: "U", 31: "V", 32: "W", 33: "X", 34: "Y", 35: "Z"
        }
        wagi = [7, 3, 1, 9, 7, 3, 1, 7, 3, 1, 7, 3, 1, 7, 3, 1, 7, 3, 1, 7, 3, 1, 7, 3, 1, 7, 3, 1]

        serial_number = "".join(random.choices(list(numbers_dict.values()), k=3))
        random_number = "".join(random.choices("0123456789", k=6))

        self.id_number = serial_number + random_number

        # Checksum and verification of authentication
        if self.__verify_auth():
            return self.id_number
        else:
            # If authentication fails, generate new number
            return self.generate_id()
