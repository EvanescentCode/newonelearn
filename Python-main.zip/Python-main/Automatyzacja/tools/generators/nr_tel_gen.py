import random


class RandomPhoneNumber:
	"""
	Funkcja numer telefonu zwraca randomowy numer pomiędzy 500000000,a 800000000.
	"""
	@staticmethod
	def phone_number():
		random_number = random.randint(400000000, 800000000)
		return str(random_number)
