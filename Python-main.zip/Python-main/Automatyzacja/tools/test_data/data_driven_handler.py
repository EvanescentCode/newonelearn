from openpyxl import load_workbook
from Automatyzacja.utilities.page import Utils
import logging


class DDT:
    """
    Klasa odpowiadająca za czytanie danych z pliku Excel.
    Przyjmuje argumenty: filename, sheet_name, number_of_tests.
    Zwraca listy zawierające dane z pliku Excel.
    Zmienia także pierwszy element list z int na str
    """
    log = Utils().custom_logger(log_level=logging.DEBUG)

    def __init__(self, filename: str, sheet_name: str, number_of_tests: int):
        self.filename = filename
        self.sheet_name = sheet_name
        self.num_tests = number_of_tests
        self.data = []
        self.wb = None
        self.ws = None
        self.used_data = []

    def __pkd_dict(self):
        pkd_dict = {
            'disabled': ['3812Z', '3822Z', '0721Z',
                         '2051Z', '2540Z', '2446Z',
                         '2011Z', '0721Z', '3211Z',
                         '6420Z', '6419Z', '9200Z',
                         '9329A', '3040Z', '2051Z',
                         '2446Z', '6430Z', '6612Z',
                         '9491Z', '1420Z', '3212Z',
                         '6499Z', '6611Z', '9492Z'],
            'risky': ['0510Z', '4612Z', '4671Z', ],
            'excluded': ['0170Z', '3812Z', '3822Z',
                         '0721Z', '2051Z', '2011Z',
                         '2446Z', '2540Z', '6411Z',
                         '6420Z', '6430Z', '6520Z',
                         '6530Z', '6611Z', '9492Z',
                         '9491Z'],
            'hard_to_factor': ['4110Z', '4120Z', '4211Z',
                               '4212Z', '4213Z', '4221Z',
                               '4222Z', '4291Z', '4299Z',
                               '4311Z', '4311Z', '4312Z',
                               '4313Z', '4321Z', '4322Z',
                               '4329Z', '4331Z', '4332Z',
                               '4333Z', '4334Z', '4339Z',
                               '4391Z', '4399Z', '4950A',
                               '4950B', '4619Z', '4782Z',
                               '4725Z', '4776Z', '4779Z',
                               '4791Z', '5821Z', '6491Z']
        }
        return pkd_dict

    def __workbook_handling(self):
        self.wb = load_workbook(self.filename)
        self.ws = self.wb[self.sheet_name]

    def __save_workbook(self):
        self.wb.save(self.filename)

    def __read_data(self):
        for row in self.ws.iter_rows(min_row=2, values_only=True):
            self.data.append(list(row))
        self.__save_workbook()
        return self.data

    def __data_processing(self):
        count = 0
        _dict = [value for sublist in self.__pkd_dict().values() for value in sublist]
        for row_idx, item in enumerate(self.data, start=2):
            if item[1] not in _dict:
                if item[2] == 'aktywny' and item[3] == 'N/A' and count < self.num_tests:
                    item[3] = 'PASS'
                    self.__save_workbook()
                    self.used_data.append(item)
                    count += 1
                    self.__update_excel_data(row_idx, item)
        return self.used_data

    def __update_excel_data(self, row_idx, item):
        for col_idx, value in enumerate(item, start=1):
            self.ws.cell(row=row_idx, column=col_idx, value=value)

    def process_handler(self):
        self.__workbook_handling()
        self.__read_data()
        self.used_data = []
        self.used_data = self.__data_processing()
        # self.log.info(self.used_data)
        # Nip to string
        self.log.debug(f'__Test data frame__')
        for item in self.used_data:
            item[0] = str(item[0])
            self.log.debug(f'Test data: {item}')
        self.__save_workbook()
        return self.used_data
