# add urls
test_url_1 = 'https://test2.falcon.nest.corp/FMBewnioseknew/WizardWfB.aspx?b=1&p=2&s=920&l=Faktoria&Field1=xxx'
test_url_2 = 'https://test2.falcon.nest.corp/FMBewnioseknew/WizardWfB.aspx?b=1&p=2&s=920&l=Faktoria&Field1=xxx&Field2=yyy'

preprod_url_1 = 'https://test1.falcon.nest.corp/FMBewnioseknew/WizardWfB.aspx?b=1&p=2&s=422&l=Faktoria&Field1=xxx'
preprod_url_2 = 'https://test1.falcon.nest.corp/FMBewnioseknew/WizardWfB.aspx?b=1&p=2&s=422&l=Faktoria&Field1=xxx&Field2=yyy'

prod_url_1 = 'https://wniosek.faktoria.pl/fmbewnioseknew/WizardWfB.aspx?b=1&p=2&s=355&l=Faktoria&Field1=xxx'
prod_url_2 = 'https://wniosek.nestbank.pl/fmbewnioseknew/WizardWfB.aspx?b=1&p=2&s=355&l=Faktoria&Field1=xxx&Field2=yyy'
prod_url = 'https://wnioski.nestbank.pl/FMBewnioseknew/WizardWfB.aspx?b=1&p=2&s=355&l=Faktoria&Field1=4eae35f1b35977a00ebd8086c259d4c9&bankId=1&profileId=2&c=1'
