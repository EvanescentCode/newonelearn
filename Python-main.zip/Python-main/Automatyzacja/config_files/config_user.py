SPING0_URL = ''
ADD_URL = ''
LOG = ''
BROWSER = ''
ENV = ''


class ConfigFile:

    def spingo_url(self):
        pass

    def add_url(self):
        pass

    def log(self):
        pass

    def browser(self):
        pass

    def env(self):
        pass

    # TODO: implement
