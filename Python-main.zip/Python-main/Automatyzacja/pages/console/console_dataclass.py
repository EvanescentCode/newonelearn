import datetime
from dataclasses import dataclass


@dataclass
class ConsoleData:
    search_application_field: str
    search_only_in_my_applications_button: bool
    search_in_archive_button: bool
    application_number_field: str
    application_date_from_field: datetime
    application_date_to_field: datetime
    source_of_application_field: str
    given_to_person_field: str
    nip_field: str
    company_name_field: str
    stage_of_application_in_pdf_dropdown: None
    application_status_field: None
    sales_channel: str
    login_of_seller_field: str
    terminate_date_from_field: datetime
    terminate_date_to_field: datetime
    blocked_by_field: str
    product_type_field: str
    contractor_nip_field: str
