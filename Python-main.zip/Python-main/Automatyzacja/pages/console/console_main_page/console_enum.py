from enum import StrEnum


class ConsoleProfileEnum(StrEnum):
    FAKT_ODSTEPSTWO_CENOWE_DYREKTOR_REGIONU = 'Fakt odstępstwo cenowe dyrektor regionu (poziom 2)'
    FAKT_ODSTEPSTWO_CENOWE_DYREKTOR_SPRZEDAZY = 'Fakt odstępstwo cenowe dyrektor sprzedaży (poziom 3)'
    FAKT_ODSTEPSTWO_CENOWE_ZARZAD = 'Fakt odstępstwo cenowe zarząd (poziom 4)'
    FAKT_ADMIN = 'FAKT_ADMIN'
    FAKT_API = 'FAKT_API'
    FAKT_API_ECOM = 'FAKT_API_ECOM'
    FAKT_DYREKTOR_REGIONU = 'FAKT_Dyrektor_Regionu'
    FAKT_DYREKTOR_SPRZEDAZY = 'FAKT_Dyrektor_Sprzedazy'
    FAKT_KIEROWNIK_ODDZIALU_ZESPOLU = 'FAKT_Kierownik_Oddziału/Zespolu'
    FAKT_KLIENT = 'FAKT_Klient'
    FAKT_OBSLUGA_KOLEJKI_ZLECEN = 'FAKT_Obsługa_Kolejki_Zlecen'
    FAKT_ODSTEPSTWA_CENOWE = 'FAKT_Odstepstwa_cenowe'
    FAKT_OPERACJE_BANKU = 'FAKT_Operacje_Banku'
    FAKT_OPERACJE_FAKTORINGU = 'FAKT_Operacje_Faktoringu'
    FAKT_OPERATOR = 'FAKT_Operator [*]'
    FAKT_PODGLAD_API = 'FAKT_Podglad_API'
    FAKT_PODGLAD = 'FAKT_Podgląd'
    FAKT_PRACOWNIK_AML = 'FAKT_Pracownik_AML'
    FAKT_PRACOWNIK_CC = 'FAKT_Pracownik_CC'
    FAKT_PRACOWNIK_ODDZIAL = 'FAKT_Pracownik_Oddział'
    FAKT_PRZYGOTOWANIE_DOKUMENTOW = 'FAKT_Przygotowanie_Dokumentow'
    FAKT_ZARZAD = 'FAKT_Zarząd'
    FAKTORING_ADMINISTRATOR_REJESTROW_RYZYKA = 'Faktoring - administrator rejestrów ryzyka'
    FAKTORING_ECOMMERCE_OBSLUGA = 'Faktoring - ecommerce obsługa'
    FAKTORING_RELACJE = 'Faktoring - Relacje'
    FAKTORING_RYZYKO = 'Faktoring - Ryzyko'
    FAKTORING_WPROWADZANIE_DANYCH = 'Faktoring - wprowadzanie danych'
    FAKTORING_OPERATOR_RYZYKO = 'Faktoring operator ryzyko'


class RegistersEnum(StrEnum):
    REGISTER_FACTORING = 'Rejestr FAKTORING'
    REGISTER_OF_START = 'Rejestr uruchomień'


class RegisterMIKROEnum(StrEnum):
    GLO_QUESTIONS_PRODUCT = 'GLO_PYTANIA_PRODUKT'
    GRACE_PERIOD = 'Karencja'
    Register_OF_PARTNERSHIP = 'Rejestry spółek'
    Register_OF_PARTNERSHIP_IN = 'Rejestry spółek'
    REGISTER_OF_PARTNERSHIP_SHAREHOLDERS = 'Rejestry spółek udziałowcy'


class RegisterFactoring(StrEnum):
    FACTORING_ODM_CODES_FOR_MEDIATOR = 'Faktoring - kody odmów dla pośrednika'
    COURIER_FACTORING = 'Kurier - Faktoring'
    FACTORING_AGREEMENTS_STATEMENT_PROHIBITIONS = 'Faktoring - zgody, oświadczenia i zakazy'
    REGISTER_OF_RISK = 'Rejestry ryzyka'
    REGISTER_FPAY_E_COMMERCE = 'Rejestry FPAY E-commerce'
    STRUCTURE_OF_SALES = 'Struktura sprzedaży'
    ODM_CODES = 'Kody odmów'
    FAKTORIA_CATALOG_OF_AGREEMENTS = 'Faktoria - katalog zgód'
    APPLICATION_PENDING = 'Wniosek w toku'
    REGISTER_OF_AML = 'Rejestry AML'


class ConsoleSettingsLanguage(StrEnum):
    POLISH = 'Polski'
    ENGLISH = 'Angielski'
    GERMAN = 'German'


class RegisterEnum(StrEnum):
    REGISTER_FACTORING = RegistersEnum
    REGISTER_MIKRO = RegisterMIKROEnum


class ConsoleSettings(StrEnum):
    NOTIFICATIONS = 'Powiadomienia'
    CHANGE_LANGUAGE = ConsoleSettingsLanguage
