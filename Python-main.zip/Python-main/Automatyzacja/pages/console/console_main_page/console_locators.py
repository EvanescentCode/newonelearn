from Automatyzacja.utilities.locator_builder import LocatorBuilder


class CommonConsoleLocators:
    # Dropdown Profile
    DROPDOWN_PROFILE_BUTTON = LocatorBuilder.css('a[class="dropdown-toggle noPadding fepSesionInfo"]')
    # Registers
    REGISTERS_DROPDOWN = LocatorBuilder.xpath('//a[@class="dropdown-toggle NavBarRootButton" and text()="Rejestry "]')
    # Registers Micro
    REGISTERS_MICRO_DROPDOWN = LocatorBuilder.xpath(
        '//a[@class="dropdown-toggle NavBarRootButton" and text()="Rejestry MIKRO "]')
    # Registers Factoring
    REGISTERS_FACTORING_DROPDOWN = LocatorBuilder.xpath(
        '//a[@class="dropdown-toggle NavBarRootButton" and text()="Rejestry Faktoring "]')
    # Registers Factoring
    SETTINGS_DROPDOWN = LocatorBuilder.xpath(
        '//a[@class="dropdown-toggle NavBarRootButton" and text()="Ustawienia "]')
    # Search
    SEARCH_APPLICATION_FIELD = LocatorBuilder.name('ctl00$MainContent$Content_searchParamsCommonExt__SEARCH_APP__')
    SEARCH_ONLY_IN_MY_APPLICATIONS_BUTTON = LocatorBuilder.id(
        'MainContent_UI_searchParamsCommonExt__SEARCH_IN_MY_APPS__')
    SEARCH_IN_ARCHIVE_BUTTON = LocatorBuilder.name('MainContent_UI_searchParamsCommonExt__SEARCH_IN_ARCHIVE__')
    APPLICATION_NUMBER_FIELD = LocatorBuilder.name('ctl00$MainContent$Content_searchParamsCommonExt_ApplicationNumber')
    APPLICATION_DATE_FROM_FIELD = LocatorBuilder.name(
        'ctl00$MainContent$Content_searchParamsCommonExt_ApplicationDate__FROM')
    APPLICATION_DATE_TO_FIELD = LocatorBuilder.name(
        'ctl00$MainContent$Content_searchParamsCommonExt_ApplicationDate__TO')
    SOURCE_OF_APPLICATION_FIELD = LocatorBuilder.name('ctl00$MainContent$Content_searchParamsCommonExt_WebSite')
    GIVEN_TO_PERSON_FIELD = LocatorBuilder.name(
        'ctl00$MainContent$Content_searchParamsCommonExt_ResponsiblePersonLogin')
    NIP_FIELD = LocatorBuilder.name('ctl00$MainContent$Content_searchParamsCommonExt_TaxNumber')
    COMPANY_NAME_FIELD = LocatorBuilder.name('ctl00$MainContent$Content_searchParamsCommonExt_FirmName')
    STAGE_OF_APPLICATION_IN_PDF_DROPDOWN = LocatorBuilder.name(
        'ctl00$MainContent$Content_searchParamsCommonExt_FieldString92')
    APPLICATION_STATUS_FIELD = LocatorBuilder.name(
        'ctl00$MainContent$Content_____SEARCH_APP____ST_MainContent_searchParamsCommonExt')
    SALES_CHANNEL = LocatorBuilder.name('ctl00$MainContent$Content_searchParamsCommonExt_Field5')
    LOGIN_OF_SELLER_FIELD = LocatorBuilder.name('ctl00$MainContent$Content_searchParamsCommonExt_Field6')
    TERMINATE_DATE_FROM_FIELD = LocatorBuilder.name('ctl00$MainContent$Content_searchParamsCommonExt_Field11__FROM')
    TERMINATE_DATE_TO_FIELD = LocatorBuilder.name('ctl00$MainContent$Content_searchParamsCommonExt_Field11__TO')
    BLOCKED_BY_FIELD = LocatorBuilder.name('ctl00$MainContent$Content_searchParamsCommonExt_ProcessedBy')
    PRODUCT_TYPE_FIELD = LocatorBuilder.name('ctl00$MainContent$Content_searchParamsCommonExt_FieldString30')
    CONTRACTOR_NIP_FIELD = LocatorBuilder.name('ctl00$MainContent$Content_searchParamsCommonExt_FieldString50')
    SEARCH_BUTTON = LocatorBuilder.css('span[class="fa fa-search"]')

    @staticmethod
    def located_application_by_nip(nip: str):
        return LocatorBuilder.xpath(f'//tr[@role="row"]//td[contains(., "{nip}")]/..//div//a')
