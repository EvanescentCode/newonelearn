from Automatyzacja.base.base_driver import Page
from Automatyzacja.pages.console.console_dataclass import ConsoleData
from Automatyzacja.pages.console.console_main_page.console_locators import CommonConsoleLocators as Locs
from Automatyzacja.utilities.page import Utils
import logging


class ConsoleMain(Page):
    log = Utils().custom_logger(log_level=logging.DEBUG)

    def __init__(self, driver):
        super().__init__(driver)
        self.driver = driver

    def fill_and_go_next(self, data: ConsoleData):
        self.choose_profile()
        self.search_application()

    def choose_profile(self, profile_name: str = "FAKT_Operator"):
        dropdown_menu = self.driver.find_element(Locs.DROPDOWN_PROFILE_BUTTON)
        self.driver.Select.select_by_visible_text(dropdown_menu, profile_name)

    def search_application(self, fkt: str, nip: str):
        self.driver.find_element(Locs.NIP_FIELD).send_keys(fkt)
        self.driver.find_element(Locs.SEARCH_BUTTON).click()
        self.driver.find_element(Locs.located_application_by_nip(nip=nip)).click()
