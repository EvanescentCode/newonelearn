from enum import StrEnum


class IDEnum(StrEnum):
    ID = 'Dowód osobisty'
    POLISH_PASSPORT = 'Paszport polski'
    FOREIGN_PASSPORT = 'Paszport zagraniczny'
    RESIDENCE_CARD = 'Karta pobytu'
