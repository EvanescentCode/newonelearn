from Automatyzacja.base.base_driver import Page
from Automatyzacja.pages.spingo_and_add.common.common_spingo_and_add.common_ekran0.common_ekran0_data import \
    CommonEkran0Data
from Automatyzacja.pages.spingo_and_add.common.common_spingo_and_add.common_ekran0.common_ekran0_locators import \
    SharedEkran0Locators as Locs
from Automatyzacja.utilities.page import Utils
import logging


class CommonEkran0(Page):
    log = Utils().custom_logger(log_level=logging.DEBUG)

    def __init__(self, driver):
        super().__init__(driver)
        self.driver = driver

    def fill_and_go_next(self, data: CommonEkran0Data):
        self.accept_cookies()
        self.input_nip_field(data.nip)
        self.search_button()

    def input_nip_field(self, nip: str):
        return self.send_keys(Locs.INPUT_NIP, nip)

    def search_button(self):
        return self.click(Locs.SEARCH_BUTTON_0)

    def accept_cookies(self):
        return self.click(Locs.ACCEPT_COOKIES)

    def decline_cookies(self):
        return self.click(Locs.DECLINE_COOKIES)
