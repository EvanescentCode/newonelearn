from dataclasses import dataclass


@dataclass
class CommonEkran0Data:
    nip: str
