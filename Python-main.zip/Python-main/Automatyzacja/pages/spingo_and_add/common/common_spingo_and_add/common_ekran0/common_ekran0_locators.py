from Automatyzacja.utilities.locator_builder import LocatorBuilder


class SharedEkran0Locators:
    ACCEPT_COOKIES = LocatorBuilder.css('a#hs-eu-confirmation-button')
    DECLINE_COOKIES = LocatorBuilder.css('a#hs-eu-decline-button')
    SEARCH_BUTTON_0 = LocatorBuilder.css('input[value="Wyszukaj"]')
    INPUT_NIP = LocatorBuilder.css('input#ctl00_CPH_Content__V_FKT_FPAY_FIRMA_DANE__Q__NIP')
