from Automatyzacja.utilities.locator_builder import LocatorBuilder


class SharedEkran1Locators:
    APARTMENT_NUMBER = LocatorBuilder.css(
        'input#ctl00_CPH_Content__V_FKT_FPAY_FIRMA_DANE__Q__ADRES_SIEDZIBY__Q__NR_MIESZKANIA')
    PHONE_NUMBER = LocatorBuilder.css('input#ctl00_CPH_Content__V_FKT_FPAY_FIRMA_DANE__Q__TELEFON_KOMORKOWY')
    E_MAIL = LocatorBuilder.css('input#ctl00_CPH_Content__V_FKT_FPAY_FIRMA_DANE__Q__EMAIL')
    DECLARATIONS_ALL_BUTTON = LocatorBuilder.xpath(
        '//input[@id="ctl00_CPH_UI__V_FKT_FPAY_ZGODA_FIRMY_1__Q__CheckBox"]/..')
    DECLARATIONS_STATUE_SPINGO = LocatorBuilder.css('input#ctl00_CPH_UI__V_FKT_FPAY_ZGODA_FIRMY_2__Q__CheckBox')
    DECLARATIONS_MARKETING_CONSENT_TEL = LocatorBuilder.css(
        'input#ctl00_CPH_UI__V_ZGODY_FIRMY_NEW__Q____ABL__1__ABR____Q__WYBOR__Q__CheckBox')
    DECLARATIONS_MARKETING_CONSENT_SMS = LocatorBuilder.css(
        'input#ctl00_CPH_UI__V_ZGODY_FIRMY_NEW__Q____ABL__2__ABR____Q__WYBOR__Q__CheckBox')
    DECLARATIONS_MARKETING_CONSENT_E_MAIL = LocatorBuilder.css(
        'input#ctl00_CPH_UI__V_ZGODY_FIRMY_NEW__Q____ABL__3__ABR____Q__WYBOR__Q__CheckBox')
    DECLARATIONS_MARKETING_CONSENT_INTERNET = LocatorBuilder.css(
        'input#ctl00_CPH_UI__V_ZGODY_FIRMY_NEW__Q____ABL__4__ABR____Q__WYBOR__Q__CheckBox')
    DECLARATIONS_MARKETING_CONSENT_DENY = LocatorBuilder.css(
        'input#ctl00_CPH_UI__V_ZGODY_FIRMY_NEW__Q____ABL__5__ABR____Q__WYBOR__Q__CheckBox')
    DECLARATIONS_PERSONAL_DATA_MARKET = LocatorBuilder.css(
        'input#ctl00_CPH_UI__V_ZGODY_FIRMY_NEW__Q____ABL__6__ABR____Q__WYBOR__Q__CheckBox')
    DECLARATIONS_PERSONAL_DATA_TEL = LocatorBuilder.css(
        'input#ctl00_CPH_UI__V_ZGODY_FIRMY_NEW__Q____ABL__7__ABR____Q__WYBOR__Q__CheckBox')
    DECLARATIONS_PERSONAL_DATA_SMS = LocatorBuilder.css(
        'input#ctl00_CPH_UI__V_ZGODY_FIRMY_NEW__Q____ABL__8__ABR____Q__WYBOR__Q__CheckBox')
    DECLARATIONS_PERSONAL_DATA_E_MAIL = LocatorBuilder.css(
        'input#ctl00_CPH_UI__V_ZGODY_FIRMY_NEW__Q____ABL__9__ABR____Q__WYBOR__Q__CheckBox')
    DECLARATIONS_PERSONAL_DATA_INTERNET = LocatorBuilder.css(
        'input#ctl00_CPH_UI__V_ZGODY_FIRMY_NEW__Q____ABL__10__ABR____Q__WYBOR__Q__CheckBox')
    DECLARATIONS_AUTHORIZATION_NEST = LocatorBuilder.css(
        'input#ctl00_CPH_UI__V_ZGODY_FIRMY_NEW__Q____ABL__12__ABR____Q__WYBOR__Q__CheckBox')
    NEXT_BUTTON = LocatorBuilder.css('input[value="Dalej"]')
    INFORMATION_SMS_OK_BUTTON = LocatorBuilder.css('a#ctl00_CPH_MessageDialog_lbB1')
    VERIFICATION_CODE_SMS_INPUT = LocatorBuilder.css('input#ctl00_CPH_Content_FKT_FPAY_WPROWADZ_PIN')
    VERIFICATION_CODE_SMS_ACCEPT = LocatorBuilder.css(
        'input#ctl00_CPH_nav_DANE_FIRMY_Button4_PP020_NOWY_WNIOSEK_A040_POTWIERDZ_PIN')
    APP_NUMBER = LocatorBuilder.css('input#ctl00_CPH_appnum')
