from Automatyzacja.base.base_driver import Page
from Automatyzacja.pages.spingo_and_add.common.common_spingo_and_add.common_ekran1.common_ekran1_data import \
    CommonEkran1Data
from Automatyzacja.pages.spingo_and_add.common.common_spingo_and_add.common_ekran1.common_ekran1_locators import \
    SharedEkran1Locators as Locs
import logging
from Automatyzacja.utilities.page import Utils


class CommonEkran1(Page):
    """
    Klasa ta odpowiada za określenie lokatorów strony 1 w procesie Spingo Standard.
    Następnie wykonuje select na każdym z wyżej wymienionych elementów i je zwraca.
    Następnie są wykonywane na tych elementach różne akcje i funkcję te są następnie
    wywoływane w testcase.
    """

    log = Utils().custom_logger(log_level=logging.DEBUG)

    def fill_and_go_next(self, data: CommonEkran1Data):
        self.apartment_number(data.apartment_number)
        self.phone_number(data.phone)
        self.e_mail(data.email)
        self.declarations_all_button()
        self.next_button()
        self.log.info(self.app_number())
        try:
            self.information_sms_ok_button()
            self.verification_code_sms_input(data.sms_code)
            self.verification_code_sms_accept()
        except (Exception,):
            pass

    def apartment_number(self, apartment_number: str):
        self.send_keys(Locs.APARTMENT_NUMBER, apartment_number)

    def phone_number(self, phone_number: str):
        self.send_keys(Locs.PHONE_NUMBER, phone_number)

    def e_mail(self, e_mail: str):
        self.send_keys(Locs.E_MAIL, e_mail)

    def declarations_all_button(self):
        self.click(Locs.DECLARATIONS_ALL_BUTTON)

    def declarations_statue_spingo(self):
        self.click(Locs.DECLARATIONS_STATUE_SPINGO)

    def declarations_marketing_consent_tel(self):
        self.click(Locs.DECLARATIONS_MARKETING_CONSENT_TEL)

    def declarations_marketing_consent_sms(self):
        self.click(Locs.DECLARATIONS_MARKETING_CONSENT_SMS)

    def declarations_marketing_consent_e_mail(self):
        self.click(Locs.DECLARATIONS_MARKETING_CONSENT_E_MAIL)

    def declarations_marketing_consent_internet(self):
        self.click(Locs.DECLARATIONS_MARKETING_CONSENT_INTERNET)

    def declarations_marketing_consent_deny(self):
        self.click(Locs.DECLARATIONS_MARKETING_CONSENT_DENY)

    def declarations_personal_data_marketing(self):
        self.click(Locs.DECLARATIONS_PERSONAL_DATA_MARKET)

    def declarations_personal_data_tel(self):
        self.click(Locs.DECLARATIONS_PERSONAL_DATA_TEL)

    def declarations_personal_data_sms(self):
        self.click(Locs.DECLARATIONS_PERSONAL_DATA_SMS)

    def declarations_personal_data_e_mail(self):
        self.click(Locs.DECLARATIONS_PERSONAL_DATA_E_MAIL)

    def declarations_personal_data_internet(self):
        self.click(Locs.DECLARATIONS_PERSONAL_DATA_INTERNET)

    def declarations_authorization_nest(self):
        self.click(Locs.DECLARATIONS_AUTHORIZATION_NEST)

    def next_button(self):
        self.click(Locs.NEXT_BUTTON)

    def information_sms_ok_button(self):
        self.click(Locs.INFORMATION_SMS_OK_BUTTON)

    def verification_code_sms_input(self, verification_code_sms_input: str):
        self.send_keys(Locs.VERIFICATION_CODE_SMS_INPUT, verification_code_sms_input)

    def verification_code_sms_accept(self):
        self.click(Locs.VERIFICATION_CODE_SMS_ACCEPT)

    def app_number(self):
        return Locs.APP_NUMBER
