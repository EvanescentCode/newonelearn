from dataclasses import dataclass

from Automatyzacja.tools.generators.nr_tel_gen import RandomPhoneNumber


@dataclass
class CommonEkran1Data:
    apartment_number: str
    email: str
    phone: str = RandomPhoneNumber.phone_number()
    sms_code: str = '6666'
    # name: str
    # surname: str
