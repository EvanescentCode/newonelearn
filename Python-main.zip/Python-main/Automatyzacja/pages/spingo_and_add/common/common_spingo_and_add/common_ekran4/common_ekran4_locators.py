from Automatyzacja.utilities.locator_builder import LocatorBuilder


class SharedEkran4Locators:
    AGREEMENT_TEMPLATE = LocatorBuilder.css('a#ctl00_CPH_Content_linFile_V_FKT_FPAY_POROZUMIENIE__Q__POROZUMIENIE')
    PAY_SPINGO_BTN = LocatorBuilder.css('input[value="Zapłać common_spingo_and_add"]')
