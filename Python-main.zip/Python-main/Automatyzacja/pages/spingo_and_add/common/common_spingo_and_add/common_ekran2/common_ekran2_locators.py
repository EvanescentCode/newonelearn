from Automatyzacja.utilities.locator_builder import LocatorBuilder


class CommonEkran2Locators:
    PESEL = LocatorBuilder.css('input#ctl00_CPH_Content__V_FKT_FPAY_KLIENT_DANE_UZUPELNIAJACE__Q__PESEL')
    ID_TYPE_BUTTON = LocatorBuilder.css(
        'button[data-id=ctl00_CPH_Content__V_FKT_FPAY_KLIENT_DANE_UZUPELNIAJACE__Q__RODZAJ_DOKUMENTU_TOZSAMOSCI]')
    DROPDOWN_MENU = LocatorBuilder.css('ul[class="dropdown-menu inner"] li[data-original-index="1"]')
    ID_NUMBER = LocatorBuilder.css(
        'input#ctl00_CPH_Content__V_FKT_FPAY_KLIENT_DANE_UZUPELNIAJACE__Q__NUMER_DOKUMENTU_TOZSAMOSCI')
    DECLARATIONS_ALL = LocatorBuilder.xpath(
        '//input[@id="ctl00_CPH_UI__V_FKT_FPAY_KLIENT_DANE_UZUPELNIAJACE__Q__ZGODA_5__Q__CheckBox"]/..')
    DECLARATIONS_DATA_CONFIRMATION = LocatorBuilder.css(
        'input#ctl00_CPH_UI__V_FKT_FPAY_KLIENT_DANE_UZUPELNIAJACE__Q__ZGODA_1__Q__CheckBox')
    DECLARATIONS_FAKTORIA_AUTHORIZATION = LocatorBuilder.css(
        'input#ctl00_CPH_UI__V_FKT_FPAY_KLIENT_DANE_UZUPELNIAJACE__Q__ZGODA_2__Q__CheckBox')
    DECLARATIONS_EQUITY_LINKS = LocatorBuilder.css(
        'input#ctl00_CPH_UI__V_FKT_FPAY_KLIENT_DANE_UZUPELNIAJACE__Q__ZGODA_3__Q__CheckBox')
    DECLARATIONS_PEP = LocatorBuilder.css(
        'input#ctl00_CPH_UI__V_FKT_FPAY_KLIENT_DANE_UZUPELNIAJACE__Q__ZGODA_4__Q__CheckBox')
    NEXT_BUTTON = LocatorBuilder.css('input[value="Dalej"]')
    VERIFICATION_CODE_SMS_INPUT = LocatorBuilder.css('input#ctl00_CPH_Content_FKT_FPAY_WPROWADZ_PIN_UZUPELNIAJACE')
    VERIFICATION_CODE_SMS_ACCEPT_BUTTON = LocatorBuilder.css('input[value="Potwierdź"]')
    OK_INFORMATION = LocatorBuilder.css('a[class="ToolButtonS fepDialogInfo"]')
