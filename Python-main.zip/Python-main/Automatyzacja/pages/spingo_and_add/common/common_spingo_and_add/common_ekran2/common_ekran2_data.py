from dataclasses import dataclass

from Automatyzacja.pages.spingo_and_add.common.common_enum.common_enum import IDEnum
from Automatyzacja.tools.generators.dok_toz_gen import IDGenerator
from Automatyzacja.tools.generators.pesel_generator import PeselGen


@dataclass
class CommonEkran2Data:
    dropdown_menu: IDEnum
    pesel: str = PeselGen
    id_number: str = IDGenerator
    sms_code: str = '6666'

