from Automatyzacja.base.base_driver import Page
from Automatyzacja.pages.spingo_and_add.common.common_enum.common_enum import IDEnum
from Automatyzacja.pages.spingo_and_add.common.common_spingo_and_add.common_ekran2.common_ekran2_data import \
    CommonEkran2Data
from Automatyzacja.pages.spingo_and_add.common.common_spingo_and_add.common_ekran2.common_ekran2_locators import \
    CommonEkran2Locators as Locs
from Automatyzacja.utilities.page import Utils
import logging


class CommonEkran2(Page):
    log = Utils().custom_logger(log_level=logging.DEBUG)

    def __init__(self, driver):
        super().__init__(driver)
        self.driver = driver

    def fill_and_go_next(self, data: CommonEkran2Data):
        self.pesel_input(data.pesel)
        self.id_type_button_btn()
        self.dropdown_menu(data.dropdown_menu)
        self.id_number(data.id_number)
        self.declarations_all_button()
        self.next_button()
        self.ok_information_button()
        self.verification_code_sms_input(data.sms_code)
        self.verification_code_sms_accept_button()
        self.ok_information()

    def pesel_input(self, pesel: str):
        self.send_keys(Locs.PESEL, pesel)

    def id_type_button_btn(self):
        self.click(Locs.ID_TYPE_BUTTON)

    def dropdown_menu(self, value: IDEnum):
        self.select_from_dropdown(Locs.DROPDOWN_MENU, value)

    def id_number(self, id_number: str):
        self.send_keys(Locs.ID_NUMBER, id_number)

    def declarations_all_button(self):
        self.click(Locs.DECLARATIONS_ALL)

    def declarations_data_confirmation_button(self):
        self.click(Locs.DECLARATIONS_DATA_CONFIRMATION)

    def declarations_faktoria_authorization_button(self):
        self.click(Locs.DECLARATIONS_FAKTORIA_AUTHORIZATION)

    def declarations_equity_links_button(self):
        self.click(Locs.DECLARATIONS_EQUITY_LINKS)

    def declarations_pep_button(self):
        self.click(Locs.DECLARATIONS_PEP)

    def next_button(self):
        self.click(Locs.NEXT_BUTTON)

    def ok_information_button(self):
        self.click(Locs.OK_INFORMATION)

    def verification_code_sms_input(self, sms_input: str):
        self.send_keys(Locs.VERIFICATION_CODE_SMS_INPUT, sms_input)

    def verification_code_sms_accept_button(self):
        self.click(Locs.VERIFICATION_CODE_SMS_ACCEPT_BUTTON)

    def ok_information(self):
        self.click(Locs.OK_INFORMATION)
