from dataclasses import dataclass


@dataclass
class CommonEkran3Data:
    verification_code_sms: str = '6666'
