from Automatyzacja.utilities.locator_builder import LocatorBuilder


class SharedEkran3Locators:
    VERIFICATION_CODE_SMS = LocatorBuilder.css('input#ctl00_CPH_Content__V_FKT_FPAY_OFERTA__Q__KOD_PIN')
    VERIFICATION_CODE_CONFIRM_BUTTON = LocatorBuilder.css('input[value="Potwierdź"]')