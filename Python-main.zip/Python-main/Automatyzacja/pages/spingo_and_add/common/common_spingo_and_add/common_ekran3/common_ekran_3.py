from Automatyzacja.base.base_driver import Page
from Automatyzacja.pages.spingo_and_add.common.common_spingo_and_add.common_ekran3.common_ekran3_data import \
    CommonEkran3Data
from Automatyzacja.pages.spingo_and_add.common.common_spingo_and_add.common_ekran3.common_ekran3_locators import \
    SharedEkran3Locators as Locs
from Automatyzacja.utilities.page import Utils
import logging


class CommonEkran3(Page):
    log = Utils().custom_logger(log_level=logging.DEBUG)

    def __init__(self, driver):
        super().__init__(driver)
        self.driver = driver

    def fill_and_go_next(self, data: CommonEkran3Data):
        self.verification_code_sms_input(data.verification_code_sms)
        self.verification_code_confirm_button()

    # Funkcje docelowe
    def verification_code_sms_input(self, sms_inpt: str):
        self.send_keys(Locs.VERIFICATION_CODE_SMS, sms_inpt)

    def verification_code_confirm_button(self):
        self.click(Locs.VERIFICATION_CODE_CONFIRM_BUTTON)
