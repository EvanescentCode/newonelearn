from dataclasses import dataclass

from Automatyzacja.pages.console.console_dataclass import ConsoleData
from Automatyzacja.pages.spingo_and_add.add_screens.add_ekran1.add_ekran1_data import ADDEkran1Data
from Automatyzacja.pages.spingo_and_add.add_screens.add_ekran3.add_ekran3_data import ADDEkran3Data
from Automatyzacja.pages.spingo_and_add.common.common_spingo_and_add.common_ekran0.common_ekran0_data import \
    CommonEkran0Data
from Automatyzacja.pages.spingo_and_add.common.common_spingo_and_add.common_ekran1.common_ekran1_data import \
    CommonEkran1Data
from Automatyzacja.pages.spingo_and_add.common.common_spingo_and_add.common_ekran2.common_ekran2_data import \
    CommonEkran2Data
from Automatyzacja.pages.spingo_and_add.common.common_spingo_and_add.common_ekran3.common_ekran3_data import \
    CommonEkran3Data
from Automatyzacja.pages.spingo_and_add.standard_screens.second_trans_standard_screens.ekran1.ekran1_data import \
    Ekran1Data
from Automatyzacja.pages.spingo_and_add.standard_screens.second_trans_standard_screens.ekran2.ekran2_data import \
    Ekran2Data
from Automatyzacja.pages.spingo_and_add.standard_screens.second_trans_standard_screens.ekran3.ekran3_data import \
    Ekran3Data


@dataclass
class ADDScreensData:
    ekran0: CommonEkran0Data
    ekran1: ADDEkran1Data
    ekran2: None
    ekran3: ADDEkran3Data


@dataclass
class ANRData:
    ekran0: None


@dataclass
class SpingoStandardFirstTransactionData:
    ekran0: CommonEkran0Data
    ekran1: CommonEkran1Data
    ekran2: CommonEkran2Data
    ekran3: CommonEkran3Data


@dataclass
class SpingoStandardSecondTransactionData:
    ekran0: CommonEkran0Data
    ekran1: Ekran1Data
    ekran2: Ekran2Data
    ekran3: Ekran3Data


@dataclass
class LimitBezTransakcjiData:
    ekran0: CommonEkran0Data
    ekran1: CommonEkran1Data
    ekran2: CommonEkran2Data
    ekran3: CommonEkran3Data


@dataclass
class SpingoAndAddData:
    add_screens_data: ADDScreensData
    anr: ANRData
    spingo_standard_first_transaction_data: SpingoStandardFirstTransactionData
    spingo_standard_second_transaction_data: SpingoStandardSecondTransactionData
    limit_bez_transakcji_data: LimitBezTransakcjiData
    console_data: ConsoleData
