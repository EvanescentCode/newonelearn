from Automatyzacja.base.base_driver import Page
from Automatyzacja.utilities.page import Utils
from selenium.webdriver.common.by import By
import logging


class LimitEkran4(Page):

    """
    Klasa ta odpowiada za określenie lokatorów strony 4 w procesie Spingo Standard.
    Następnie wykonuje select na każdym z wyżej wymienionych elementów i je zwraca.
    Następnie są wykonywane na tych elementach różne akcje i funkcję te są następnie
    wywoływane w testcase.
    """

    log = Utils().custom_logger(log_level=logging.DEBUG)

    def __init__(self, driver):
        super().__init__(driver)
        self.driver = driver

    # Locators
    AGREEMENT_TEMPLATE = 'a#ctl00_CPH_Content_linFile_V_FKT_FPAY_POROZUMIENIE__Q__POROZUMIENIE'
    PAY_SPINGO_BTN = 'input[value="Dalej"]'
    
    def agreement_template_field(self):
        return self.wait_for_item_to_be_clickable(By.CSS_SELECTOR, self.AGREEMENT_TEMPLATE)
    
    def pay_spingo_button_field(self):
        return self.long_wait_for_item_to_be_clickable(By.CSS_SELECTOR, self.PAY_SPINGO_BTN)
    
    # Funkcje docelowe
    def agreement_template(self):
        self.agreement_template_field().click()
    
    def pay_spingo_button(self):
        self.pay_spingo_button_field().click()
        self.log.info('Pay by common_spingo_and_add button has been clicked')

    def ekran4(self):
        self.pay_spingo_button()