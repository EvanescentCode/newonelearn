from Automatyzacja.base.base_driver import Page
from Automatyzacja.pages.spingo_and_add.add_screens.add_ekran3.add_ekran3_data import ADDEkran3Data
from Automatyzacja.pages.spingo_and_add.add_screens.add_ekran3.add_ekran3_locators import ADDEkran3Locators as Locs


class ADDEkran3(Page):

    def fill_and_go_next(self, data: ADDEkran3Data):
        self.personal_name(data.personal_name)
        self.personal_position(data.personal_position)
        self.personal_pesel(data.personal_pesel)
        self.id_number(data.id_number)
        self.personal_email(data.personal_email)
        self.personal_phone(data.personal_phone)
        self.bank_account_number(data.bank_account_number)
        self.contact_name(data.contact_name)
        self.contact_prename(data.contact_prename)
        self.contact_email(data.contact_email)
        self.contact_phone(data.contact_phone)
        self.agree_all()
        self.sms_input(data.sms_input)
        self.sms_next_button()

    def personal_name(self, personal_name: str):
        self.send_keys(Locs.PERSONAL_NAME_FIELD, personal_name)

    def personal_position(self, personal_position: str):
        self.send_keys(Locs.PERSONAL_POSITION_FIELD, personal_position)

    def personal_pesel(self, personal_pesel: str):
        self.send_keys(Locs.PERSONAL_PESEL_FIELD, personal_pesel)

    def id_number(self, id_number: str):
        self.send_keys(Locs.ID_NUMBER_FIELD, id_number)

    def personal_email(self, personal_email: str):
        self.send_keys(Locs.PERSONAL_EMAIL_FIELD, personal_email)

    def personal_phone(self, personal_phone: str):
        self.send_keys(Locs.PERSONAL_PHONE_FIELD, personal_phone)

    def bank_account_number(self, bank_account_number: str):
        self.send_keys(Locs.BANK_ACCOUNT_NUMBER_FIELD, bank_account_number)

    def contact_name(self, contact_name: str):
        self.send_keys(Locs.CONTACT_NAME_FIELD, contact_name)

    def contact_prename(self, contact_prename: str):
        self.send_keys(Locs.CONTACT_PRENAME_FIELD, contact_prename)

    def contact_email(self, contact_email: str):
        self.send_keys(Locs.CONTACT_EMAIL_FIELD, contact_email)

    def contact_phone(self, contact_phone: str):
        self.send_keys(Locs.CONTACT_PHONE_FIELD, contact_phone)

    def agree_all(self):
        self.click(Locs.AGREEMENTS_ALL_CHECKBOX)

    def agree_krs(self):
        self.click(Locs.AGREEMENTS_KRS_CHECKBOX)

    def agree_krss(self):
        self.click(Locs.AGREEMENTS_KRSS_CHECKBOX)

    def statement_data_correct(self):
        self.click(Locs.STATEMENT_DATA_CORRECT_CHECKBOX)

    def sms_input(self, sms_input: str):
        self.send_keys(Locs.SMS_INPUT_FIELD, sms_input)

    def sms_next_button(self):
        self.click(Locs.SMS_NEXT_BUTTON)
