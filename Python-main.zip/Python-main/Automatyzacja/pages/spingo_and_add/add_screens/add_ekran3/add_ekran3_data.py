from dataclasses import dataclass


@dataclass
class ADDEkran3Data:
    personal_name: str
    personal_position: str
    personal_pesel: str
    id_number: str
    personal_email: str
    personal_phone: str
    bank_account_number: str
    contact_name: str
    contact_prename: str
    contact_email: str
    contact_phone: str
    sms_input: str
