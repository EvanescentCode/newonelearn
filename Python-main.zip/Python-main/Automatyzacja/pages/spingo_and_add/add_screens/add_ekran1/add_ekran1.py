from Automatyzacja.base.base_driver import Page
from Automatyzacja.pages.spingo_and_add.add_screens.add_ekran1.add_ekran1_data import ADDEkran1Data
from Automatyzacja.pages.spingo_and_add.add_screens.add_ekran1.add_ekran1_locators import ADDEkran1Locators as Locs
from Automatyzacja.utilities.page import Utils
import logging


class ADDEkran1(Page):
    log = Utils().custom_logger(log_level=logging.DEBUG)

    def __init__(self, driver):
        super().__init__(driver)
        self.driver = driver

    def fill_and_go_next(self, data: ADDEkran1Data):
        self.company_name(data.company_name)
        self.name(data.name)
        self.surname(data.surname)
        self.email(data.email)
        self.phone(data.phone)
        self.shop_website(data.web_address)
        self.agreements_all()

    def company_name(self, company_name: str):
        self.send_keys(Locs.COMPANY_NAME, company_name)

    def name(self, name: str):
        self.send_keys(Locs.NAME, name)

    def surname(self, pre_name: str):
        self.send_keys(Locs.PRE_NAME, pre_name)

    def email(self, email: str):
        self.send_keys(Locs.EMAIL, email)

    def phone(self, phone: str):
        self.send_keys(Locs.PHONE, phone)

    def shop_website(self, shop_website: str):
        self.send_keys(Locs.SHOP_WEBSITE, shop_website)

    def agreements_all(self):
        self.click(Locs.AGREEMENTS_ALL)

    def agreements_phone(self):
        self.click(Locs.AGREEMENTS_PHONE)

    def agreements_sms(self):
        self.click(Locs.AGREEMENTS_SMS)

    def agreements_email(self):
        self.click(Locs.AGREEMENTS_EMAIL)

    def agreements_faktoria(self):
        self.click(Locs.AGREEMENTS_FAKTORIA)

    def agreements_disagreement_marketing(self):
        self.click(Locs.AGREEMENTS_DISAGREEMENT_MARKETING)

    def agreements_personal_data(self):
        self.click(Locs.AGREEMENTS_PERSONAL_DATA)

    def agreements_personal_data_phone(self):
        self.click(Locs.AGREEMENTS_PERSONAL_DATA_PHONE)

    def agreements_personal_data_sms(self):
        self.click(Locs.AGREEMENTS_PERSONAL_DATA_SMS)

    def agreements_personal_data_email(self):
        self.click(Locs.AGREEMENTS_PERSONAL_DATA_EMAIL)

    def agreements_personal_data_faktoria(self):
        self.click(Locs.AGREEMENTS_PERSONAL_DATA_FAKTORIA)

    def agreements_authorization(self):
        self.click(Locs.AGREEMENTS_AUTHORIZATION)

    def agreements_contact(self):
        self.click(Locs.AGREEMENTS_CONTACT)
