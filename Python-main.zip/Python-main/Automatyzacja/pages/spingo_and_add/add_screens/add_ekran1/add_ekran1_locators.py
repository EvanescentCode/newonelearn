from Automatyzacja.utilities.locator_builder import LocatorBuilder


class ADDEkran1Locators:
    NIP = LocatorBuilder.css('input[name="ctl00$CPH$Content__V_FKT_FPAY_FIRMA_DANE__Q__NIP"]')
    CHANGE_NIP = LocatorBuilder.css(
        'input[name="ctl00$CPH$nav_DANE_FIRMY_Button1_PP020_NOWY_WNIOSEK_A040_PRZYCISK_POPRAW_NIP"]')
    COMPANY_NAME = LocatorBuilder.name('ctl00$CPH$Content__V_FKT_FPAY_FIRMA_DANE__Q__NAZWA')
    NAME = LocatorBuilder.name('ctl00$CPH$Content__V_FKT_FPAY_FIRMA_DANE__Q__IMIE')
    PRE_NAME = LocatorBuilder.name('ctl00$CPH$Content__V_FKT_FPAY_FIRMA_DANE__Q__NAZWISKO')
    EMAIL = LocatorBuilder.name('ctl00$CPH$Content__V_FKT_FPAY_FIRMA_DANE__Q__EMAIL')
    PHONE = LocatorBuilder.name('ctl00$CPH$Content__V_FKT_FPAY_FIRMA_DANE__Q__TELEFON_KOMORKOWY')
    SHOP_WEBSITE = LocatorBuilder.name('ctl00$CPH$Content__V_FKT_FPAY_FIRMA_DANE__Q__ADRES_PLATFORMY')
    AGREEMENTS_ALL = LocatorBuilder.id('ctl00_CPH_UI__V_FKT_FPAY_ZGODA_FIRMY_1__Q__CheckBox')
    AGREEMENTS_PHONE = LocatorBuilder.id(
        'ctl00_CPH_Content__V_ZGODY_FIRMY_NEW__Q____ABL__1__ABR____Q__WYBOR__Q__CheckBoxContainer')
    AGREEMENTS_SMS = LocatorBuilder.id('ctl00_CPH_UI__V_ZGODY_FIRMY_NEW__Q____ABL__2__ABR____Q__WYBOR__Q__CheckBox')
    AGREEMENTS_EMAIL = LocatorBuilder.id('ctl00_CPH_UI__V_ZGODY_FIRMY_NEW__Q____ABL__3__ABR____Q__WYBOR__Q__CheckBox')
    AGREEMENTS_FAKTORIA = LocatorBuilder.id(
        'ctl00_CPH_UI__V_ZGODY_FIRMY_NEW__Q____ABL__4__ABR____Q__WYBOR__Q__CheckBox')
    AGREEMENTS_DISAGREEMENT_MARKETING = LocatorBuilder.id(
        'ctl00_CPH_UI__V_ZGODY_FIRMY_NEW__Q____ABL__5__ABR____Q__WYBOR__Q__CheckBox')
    AGREEMENTS_PERSONAL_DATA = LocatorBuilder.id(
        'ctl00_CPH_UI__V_ZGODY_FIRMY_NEW__Q____ABL__25__ABR____Q__WYBOR__Q__CheckBox')
    AGREEMENTS_PERSONAL_DATA_PHONE = LocatorBuilder.id(
        'ctl00_CPH_UI__V_ZGODY_FIRMY_NEW__Q____ABL__7__ABR____Q__WYBOR__Q__CheckBox')
    AGREEMENTS_PERSONAL_DATA_SMS = LocatorBuilder.id(
        'ctl00_CPH_UI__V_ZGODY_FIRMY_NEW__Q____ABL__26__ABR____Q__WYBOR__Q__CheckBox')
    AGREEMENTS_PERSONAL_DATA_EMAIL = LocatorBuilder.id(
        'ctl00_CPH_UI__V_ZGODY_FIRMY_NEW__Q____ABL__27__ABR____Q__WYBOR__Q__CheckBox')
    AGREEMENTS_PERSONAL_DATA_FAKTORIA = LocatorBuilder.id(
        'ctl00_CPH_UI__V_ZGODY_FIRMY_NEW__Q____ABL__28__ABR____Q__WYBOR__Q__CheckBox')
    AGREEMENTS_AUTHORIZATION = LocatorBuilder.id(
        'ctl00_CPH_UI__V_ZGODY_FIRMY_NEW__Q____ABL__12__ABR____Q__WYBOR__Q__CheckBox')
    AGREEMENTS_CONTACT = LocatorBuilder.id('ctl00_CPH_UI__V_ZGODY_FIRMY_NEW__Q____ABL__0__ABR____Q__WYBOR__Q__CheckBox')
    # Button Next
    NEXT_BUTTON = LocatorBuilder.name('ctl00$CPH$nav_DANE_FIRMY_Button2_PP020_NOWY_WNIOSEK_A040_DALEJ')