from dataclasses import dataclass
from Automatyzacja.tools.generators.nr_tel_gen import RandomPhoneNumber


@dataclass
class ADDEkran1Data:
    name: str
    surname: str
    email: str
    web_address: str
    phone: str = RandomPhoneNumber.phone_number()
    nip_of_company: str = None
    company_name: str = None
