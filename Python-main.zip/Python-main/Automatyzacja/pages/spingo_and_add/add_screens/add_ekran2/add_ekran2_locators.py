from Automatyzacja.utilities.locator_builder import LocatorBuilder


class ADDEkran2Locators:
    FINANCING_COST = LocatorBuilder.name('ctl00$CPH$Content_FKT_ADD_OFERTA_KOSZT_FINANSOWANIA')
    # Who takes costs
    YOU_RATIO = LocatorBuilder.name('ctl00_CPH_Content__V_FKT_ADD_OFERTA_ENUM__Q__PLATNIK__RB__0')
    YOUR_CLIENT_RADIO = LocatorBuilder.name('ctl00_CPH_Content__V_FKT_ADD_OFERTA_ENUM__Q__PLATNIK__RB__1')
    # Amount of days of postponement
    FIFTEEN_DAYS_POSTPONEMENT = LocatorBuilder.name(
        'ctl00_CPH_Content__V_FKT_ADD_OFERTA_ENUM__Q__TERMIN_PLATNOSCI__RB__0')
    THIRTY_DAYS_POSTPONEMENT = LocatorBuilder.name(
        'ctl00_CPH_Content__V_FKT_ADD_OFERTA_ENUM__Q__TERMIN_PLATNOSCI__RB__1')
    FORTY_FIVE_DAYS_POSTPONEMENT = LocatorBuilder.name(
        'ctl00_CPH_Content__V_FKT_ADD_OFERTA_ENUM__Q__TERMIN_PLATNOSCI__RB__2')
    SIXTY_DAYS_POSTPONEMENT = LocatorBuilder.name(
        'ctl00_CPH_Content__V_FKT_ADD_OFERTA_ENUM__Q__TERMIN_PLATNOSCI__RB__3')
    # Buttons
    SUBMIT_BUTTON = LocatorBuilder.name('ctl00$CPH$nav_OFERTA_Button3_PP020_NOWY_WNIOSEK_A050_POTWIERDZ')
    RETURN_BUTTON = LocatorBuilder.name('ctl00$CPH$nav_OFERTA_Button1_PP020_NOWY_WNIOSEK_A050_POWROT')

