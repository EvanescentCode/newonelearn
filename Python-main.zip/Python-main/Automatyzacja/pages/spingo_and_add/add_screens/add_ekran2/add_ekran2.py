from Automatyzacja.base.base_driver import Page
from Automatyzacja.utilities.page import Utils
import logging


class ADDEkran2(Page):
    log = Utils().custom_logger(log_level=logging.DEBUG)

    def fill_and_go_next(self):
        pass

    def click_button(self):
        pass
