from enum import StrEnum


class ADDEkran2WhoseCostEnum(StrEnum):
    TY = 'Ty'
    TWOJ_KLIENT = 'Twój klient'


class ADDEkran2PeriodEnum(StrEnum):
    FIFTEEN_DAYS = '15 DNI'
    THIRTY_DAYS = '30 DNI'
    FORTY_FIVE_DAYS = '45 DNI'
    SIXTY_DAYS = '60 DNI'
