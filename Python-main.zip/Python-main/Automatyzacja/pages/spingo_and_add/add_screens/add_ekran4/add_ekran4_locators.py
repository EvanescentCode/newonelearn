from Automatyzacja.utilities.locator_builder import LocatorBuilder


class ADDEkran4Locators:
    DOWNLOAD_DRAFT_LINK = LocatorBuilder.id('ctl00_CPH_Content_linFile_V_FKT_FPAY_POROZUMIENIE__Q__POROZUMIENIE')
    SIGN_CONTRACT_BUTTON = LocatorBuilder.name(
        'ctl00$CPH$nav_PODPISANIE_UMOWY_Button1_PP020_NOWY_WNIOSEK_PP080_PODPISANIE_UMOWY_A090_PODPISZ_UMOWE')
    DISBOUND_BUTTON = LocatorBuilder.name(
        'ctl00$CPH$nav_PODPISANIE_UMOWY_Button2_PP020_NOWY_WNIOSEK_PP080_PODPISANIE_UMOWY_A090_POWROT')
