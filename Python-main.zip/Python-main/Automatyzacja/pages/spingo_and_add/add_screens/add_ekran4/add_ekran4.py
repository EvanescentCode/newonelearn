from Automatyzacja.base.base_driver import Page
from Automatyzacja.pages.spingo_and_add.add_screens.add_ekran4.add_ekran4_locators import ADDEkran4Locators as Locs


class ADDEkran4(Page):

    def fill_and_go_next(self):
        self.download_draft_link()
        self.sign_contract_button()

    def download_draft_link(self):
        self.click(Locs.DOWNLOAD_DRAFT_LINK)

    def sign_contract_button(self):
        self.click(Locs.SIGN_CONTRACT_BUTTON)

    def disbound_button(self):
        self.click(Locs.DISBOUND_BUTTON)
