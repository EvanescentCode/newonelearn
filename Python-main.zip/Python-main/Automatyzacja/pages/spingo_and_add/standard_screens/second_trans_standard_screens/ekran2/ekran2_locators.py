from Automatyzacja.utilities.locator_builder import LocatorBuilder


class Ekran2Locators:
    PESEL = LocatorBuilder.name('ctl00$CPH$Content__V_FKT_FPAY_OFERTA__Q__PESEL')
    CONFIRM = LocatorBuilder.name(
        'ctl00$CPH$nav_POROZUMIENIE_KOLEJNY_ZAKUP_Button3_PP020_NOWY_WNIOSEK_A070_POTWIERDZ_PESEL')
