from Automatyzacja.base.base_driver import Page
from Automatyzacja.pages.spingo_and_add.standard_screens.second_trans_standard_screens.ekran2.ekran2_data import \
    Ekran2Data
from Automatyzacja.pages.spingo_and_add.standard_screens.second_trans_standard_screens.ekran2.ekran2_locators import \
    Ekran2Locators as Locs
from Automatyzacja.utilities.page import Utils
import logging


class Ekran2(Page):
    log = Utils().custom_logger(log_level=logging.DEBUG)

    def __init__(self, driver):
        super().__init__(driver)
        self.driver = driver

    def fill_and_go_next(self, data: Ekran2Data):
        self.pesel(data.pesel)
        self.confirm_button()

    def pesel(self, pesel: str):
        self.send_keys(Locs.PESEL, pesel)

    def confirm_button(self):
        self.click(Locs.CONFIRM)
