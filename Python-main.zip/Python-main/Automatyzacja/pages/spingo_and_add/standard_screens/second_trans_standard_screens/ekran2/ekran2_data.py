from dataclasses import dataclass


@dataclass
class Ekran2Data:
    pesel: str

