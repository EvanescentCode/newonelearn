from Automatyzacja.base.base_driver import Page
from Automatyzacja.pages.spingo_and_add.standard_screens.second_trans_standard_screens.ekran1.ekran1_data import \
    Ekran1Data
from Automatyzacja.pages.spingo_and_add.standard_screens.second_trans_standard_screens.ekran1.ekran1_locators import \
    Ekran1Locators as Locs
from Automatyzacja.utilities.page import Utils
import logging


class Ekran1(Page):
    log = Utils().custom_logger(log_level=logging.DEBUG)

    def __init__(self, driver):
        super().__init__(driver)
        self.driver = driver

    def fill_and_go_next(self, data: Ekran1Data):
        self.welcome_back()
        self.apartment_number(data.apartment_number)
        self.next_button()

    def welcome_back(self):
        self.click(Locs.WELCOME_BACK)

    def correct_nip(self):
        self.click(Locs.CORRECT_NIP)

    def apartment_number(self, apartment_number: str):
        self.send_keys(Locs.APARTMENT_NUMBER, apartment_number)

    def next_button(self):
        self.click(Locs.NEXT)
