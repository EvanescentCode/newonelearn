from dataclasses import dataclass


@dataclass
class Ekran1Data:
    apartment_number: str
    nip: str = None
    company_name: str = None
    REGON: str = None
    street_address: str = None
    building_number: str = None
    postal_code: str = None
    city: str = None
