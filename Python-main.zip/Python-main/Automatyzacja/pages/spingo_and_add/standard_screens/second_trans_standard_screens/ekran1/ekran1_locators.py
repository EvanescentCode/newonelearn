from Automatyzacja.utilities.locator_builder import LocatorBuilder


class Ekran1Locators:
    WELCOME_BACK = LocatorBuilder.id('ctl00_CPH_MessageDialog_lbB1')
    NIP = LocatorBuilder.name('ctl00$CPH$ctl516')
    CORRECT_NIP = LocatorBuilder.id(
        'ctl00_CPH_nav_DANE_FIRMY_KOLEJNY_ZAKUP_Button1_PP020_NOWY_WNIOSEK_A040_POPRAW_NIP_NEW')
    COMPANY_NAME = LocatorBuilder.name('ctl00$CPH$ctl519')
    REGON = LocatorBuilder.name('ctl00$CPH$ctl524')
    STREET_ADDRESS = LocatorBuilder.name('ctl00$CPH$ctl527')
    BUILDING_NUMBER = LocatorBuilder.name('ctl00$CPH$ctl530')
    APARTMENT_NUMBER = LocatorBuilder.id(
        'ctl00_CPH_Content__V_FKT_FPAY_FIRMA_DANE__Q__ADRES_SIEDZIBY__Q__NR_MIESZKANIA')
    POSTAL_CODE = LocatorBuilder.name('ctl00$CPH$ctl535')
    CITY = LocatorBuilder.name('ctl00$CPH$ctl538')
    NEXT = LocatorBuilder.name('ctl00$CPH$nav_DANE_FIRMY_KOLEJNY_ZAKUP_Button2_PP020_NOWY_WNIOSEK_A040_DALEJ')
