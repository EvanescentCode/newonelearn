from enum import StrEnum


class Ekran1Enum(StrEnum):
    pass
