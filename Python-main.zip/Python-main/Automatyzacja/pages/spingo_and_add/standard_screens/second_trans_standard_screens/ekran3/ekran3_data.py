from dataclasses import dataclass

from Automatyzacja.base.base_driver import Page
from Automatyzacja.tools.database_scripts.sms_code_extractor import SmsCodeExtractor
from Automatyzacja.pages.spingo_and_add.common.common_spingo_and_add.common_ekran1.common_ekran_1 import CommonEkran1

@dataclass
class Ekran3Data:
    sms_code: str = SmsCodeExtractor.execute_query(CommonEkran1(Page).app_number(), )

