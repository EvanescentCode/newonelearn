from Automatyzacja.utilities.locator_builder import LocatorBuilder


class Ekran3Locators:
    SMS_CODE = LocatorBuilder.id('ctl00$CPH$Content__V_FKT_FPAY_OFERTA__Q__KOD_PIN')
    SEND_CODE_AGAIN = LocatorBuilder.id('ctl00_CPH_Content_FKT_FPAY_WYSLIJ_PIN')
    PAY_SPINGO = LocatorBuilder.id(
        'ctl00_CPH_nav_POROZUMIENIE_KOLEJNY_ZAKUP_Button1_PP020_NOWY_WNIOSEK_A070_AKCEPTUJ_PORZUMIENIE')
