from Automatyzacja.base.base_driver import Page
from Automatyzacja.utilities.page import Utils
from selenium.webdriver.common.by import By
import logging


class StandardEkran5(Page):

    """
    Klasa ta odpowiada za określenie lokatorów strony 5 w procesie Spingo Standard.
    Następnie wykonuje select na każdym z wyżej wymienionych elementów i je zwraca.
    Następnie są wykonywane na tych elementach różne akcje i funkcję te są następnie
    wywoływane w testcase.
    """

    log = Utils().custom_logger(log_level=logging.DEBUG)

    def __init__(self, driver):
        super().__init__(driver)
        self.driver = driver

    # Locators
    YOUR_ORDER_IS_PAID = 'div[class="col-xs-offset-0 col-xs-12 col-sm-offset-0 col-sm-12 col-md-offset-0 col-md-12 fepColPad fepDefFont fepDefFontTab fepDefFontMob"] p'
    EMAIL_ADDRESS = '//div[@id="ctl00_CPH_Content_FKT_FPAY_KOMUNIKAT_1__lab"]//div//span[contains(text(), "Na")]'
    FIND_OUT_MORE = 'div[class=" col-xs-offset-0 col-xs-12 col-sm-offset-0 col-sm-7 col-md-offset-0 col-md-7 fepColPad fepDefFont fepDefFontTab fepDefFontMob"] p a'
    THANKS_FOR_CHOOSING_SPINGO = '//div[@regioncontrolfield="PF|FKT_FPAY_KOMUNIKAT_GRATULACJE_STANDARD_2"]//div//div//p//p'

    def your_order_field(self):
        return self.wait_for_item_to_be_clickable(By.CSS_SELECTOR, self.YOUR_ORDER_IS_PAID)

    def email_address_field(self):
        return self.wait_for_item_to_be_clickable(By.XPATH, self.EMAIL_ADDRESS)

    def find_out_more_field(self):
        return self.wait_for_item_to_be_clickable(By.XPATH, self.FIND_OUT_MORE)

    def thanks_for_choosing_spingo_field(self):
        return self.wait_for_item_to_be_clickable(By.XPATH, self.THANKS_FOR_CHOOSING_SPINGO)

    # Funkcje docelowe
    def content(self):
        try:
            self.log.info(self.your_order_field())
            self.log.info(self.email_address_field())
            self.log.info(self.find_out_more_field())
            self.log.info(self.thanks_for_choosing_spingo_field())
        except Exception as e:
            self.log.warning('content not found')

    def ekran5(self):
        pass
