from Automatyzacja.utilities.locator_builder import LocatorBuilder


class StandardEkran5Locators:
    YOUR_ORDER_IS_PAID = LocatorBuilder.css('div[class="col-xs-offset-0 col-xs-12 col-sm-offset-0 col-sm-12 col-md-offset-0 col-md-12 fepColPad fepDefFont fepDefFontTab fepDefFontMob"] p')
    EMAIL_ADDRESS = LocatorBuilder.xpath('//div[@id="ctl00_CPH_Content_FKT_FPAY_KOMUNIKAT_1__lab"]//div//span[contains(text(), "Na")]')
    FIND_OUT_MORE = LocatorBuilder.css('div[class=" col-xs-offset-0 col-xs-12 col-sm-offset-0 col-sm-7 col-md-offset-0 col-md-7 fepColPad fepDefFont fepDefFontTab fepDefFontMob"] p a')
    THANKS_FOR_CHOOSING_SPINGO = LocatorBuilder.xpath('//div[@regioncontrolfield="PF|FKT_FPAY_KOMUNIKAT_GRATULACJE_STANDARD_2"]//div//div//p//p')