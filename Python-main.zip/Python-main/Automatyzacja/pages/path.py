from pathlib import Path


class Paths:
    BASIC_ROOT = Path(__file__).parent.parent
    TEST_FOLDER_ROOT = BASIC_ROOT / "testcases"
    DATA_FOLDER = TEST_FOLDER_ROOT / "data"

    @staticmethod
    def test_data(cls, test_data: str) -> Path:
        return cls.DATA_FOLDER / f"{test_data}.json"
