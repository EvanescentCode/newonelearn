import random

import pytest
from Automatyzacja.pages.common_pages.spingo_and_add.shared_ekran0.sh_ekran_0 import SharedEkran0
from Automatyzacja.pages.common_pages.spingo_and_add.shared_ekran1 import Ekran1
from Automatyzacja.pages.common_pages.spingo_and_add.shared_ekran2 import Ekran2
from Automatyzacja.pages.common_pages.spingo_and_add.shared_ekran3 import Ekran3
from Automatyzacja.pages.common_pages.spingo_and_add.shared_ekran4 import Ekran4
from Automatyzacja.pages.spingo_and_add.standard_screens.first_trans_standard_screens.ekran5.standard_ekran_5 import StandardEkran5
from Automatyzacja.tools.link_generators.api_requests.generate_link import SendRequest
from Automatyzacja.tools.generators.pesel_generator import PeselGen
from Automatyzacja.tools.generators.dok_toz_gen import IDGenerator
from Automatyzacja.tools.generators.nr_tel_gen import RandomPhoneNumber
from Automatyzacja.tools.test_data.data_driven_handler import DDT
from Automatyzacja.utilities.page import Utils
import time
import softest
from ddt import ddt, data, unpack


@ddt
@pytest.mark.usefixtures("setup")
class SmokePozyczka(softest.TestCase):
    """
    Tutaj biznesowa część testów, znajdują się tu odwołania do klas oraz funkcji w folderze Automatyzacja
    Funkcja test_spingo_smoke przyjmuje argumenty nip_data, col2, col3, col4
    col2, col3, col4 są traktowane jako placeholder z takiego powodu, że @unpack dopisuje wartości w liczbie
    równej do liczby argumentów, po czym jak dojdzie do końca to, zapętla.
    """

    @pytest.fixture(autouse=True)
    def class_setup(self):
        self.u = Utils()
        self.e0 = SharedEkran0(self.driver)
        self.e1 = Ekran1(self.driver)
        self.e2 = Ekran2(self.driver)
        self.e3 = Ekran3(self.driver)
        self.e4 = Ekran4(self.driver)
        self.e5 = StandardEkran5(self.driver)
        url = SendRequest().send_request('pozyczka')
        self.driver.get(url)
        DDT.log.info(url)


    @data(*DDT(filename='../tools/test_data/data_driven.xlsx', sheet_name='Sheet1', number_of_tests=1).process_handler())
    @unpack
    def test_spingo_pozyczka_smoke(self, nip_data, col2, col3, col4, gender):  # (col2 = status, col3 = PKD number col4 = if taken)
        # Ekran 0
        self.e0.ekran0(nip=nip_data)
        # Ekran 1
        random_phone_number = RandomPhoneNumber()
        self.e1.ekran1(apartment_number=f'{random.randint(1,9)}', phone_number=random_phone_number.phone_number())
        # Ekran 2
        id_generator = IDGenerator()
        pesel_gen = PeselGen()
        self.e2.ekran2(pesel=str(pesel_gen.pesel(gender)), id_number=id_generator.generate_id())
        # Ekran 3
        self.e3 = Ekran3(self.driver)
        self.e3.ekran3()
        # Ekran 4
        self.e4.ekran4()
        # End
        time.sleep(5)
        # Ekran 5



