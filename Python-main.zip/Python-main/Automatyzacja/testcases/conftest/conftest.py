from datetime import datetime
import pytest
from selenium.webdriver.chrome.service import Service as ChromeService
from webdriver_manager.chrome import ChromeDriverManager
import time
from webdriver_manager.microsoft import EdgeChromiumDriverManager
from webdriver_manager.firefox import GeckoDriverManager
from selenium.webdriver.firefox.service import Service as FirefoxService
from selenium.webdriver.edge.service import Service as EdgeService
from Automatyzacja.tools.link_generators.api_requests.generate_link import SendRequest
from Automatyzacja.tools.database_scripts.db_extractor import db_extractor_main
from selenium import webdriver
import os
import glob

driver = None
max_files = 25
file_extensions = ['.jpg', '.html']


# function takes argument --browser takes value and uses it to determine browser
@pytest.fixture(autouse=True)
def setup(request, browser, url=None):
    global driver
    if browser == "chrome":
        driver = webdriver.Chrome(service=ChromeService(ChromeDriverManager().install()))
    elif browser == "firefox":
        driver = webdriver.Firefox(service=FirefoxService(GeckoDriverManager().install()))
    elif browser == "edge":
        driver = webdriver.Edge(service=EdgeService(EdgeChromiumDriverManager().install()))

    request.cls.driver = driver
    driver.maximize_window()

    yield
    driver.close()


# Console flag --browser and --url
def pytest_addoption(parser):
    parser.addoption("--browser", action="store_true", default='chrome', help="specify which browser you want to use")
    parser.addoption("--url", action="store_true", default=False, help="specify url address")


# Flag --browser
@pytest.fixture(scope="class", autouse=True)
def browser(request):
    return request.config.getoption("--browser")


# Flag --url
@pytest.fixture(scope="class", autouse=True)
def url(request):
    return request.config.getoption("--url")


# Report title
def pytest_html_report_title(report):
    report.title = "Automatyzacja common_spingo_and_add"


@pytest.hookimpl(tryfirst=True)
def pytest_configure(config):
    if not os.path.exists('reports'):
        os.makedirs('reports')
    config.option.htmlpath = '../reports/html_reports/report' + datetime.now().strftime("%d-%m-%Y %H-%M-%S") + ".html"


def delete_oldest_file():
    files = glob.glob(os.path.join('../reports/html_reports', f'*{file_extensions}'))
    if len(files) > max_files:
        oldest_file = min(files, key=os.path.getctime)
        os.remove(oldest_file)


# Hookup creating report
@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item):
    global driver
    pytest_html = item.config.pluginmanager.getplugin("html")
    outcome = yield
    report = outcome.get_result()
    extra = getattr(report, "extra", [])
    if report.when == "call":
        # Zawsze dodaje url do end-point
        extra.append(pytest_html.extras.url(SendRequest().get_field_infos()))
        xfail = hasattr(report, "wasxfail")
        if (report.skipped and xfail) or (report.failed and not xfail):
            # dodawaj dodatkowy html tylko po fail
            report_directory = os.path.dirname(item.config.option.htmlpath)
            file_name = str(int(round(time.time() * 1000))) + ".png"
            destinationfile = os.path.join(report_directory, file_name)
            db_extractor_main(__ekran1().appnum())
            # save_screenshot jest obsługiwany przez global driver, dlatego wyświetla błąd
            driver.save_screenshot(destinationfile)
            delete_oldest_file()

            if file_name:
                html = '<div><img src="%s" alt="screenshot" style="width:300px;height=200px" ' \
                       'onclick="window.open(this.src)" align="right"/></div>' % file_name
            extra.append(pytest_html.extras.html(html))
        report.extra = extra


def __ekran1():
    e1 = SharedEkran1(driver)
    return e1
