from Automatyzacja.pages.console.console_main_page.console import ConsoleMain
from Automatyzacja.pages.spingo_and_add.add_screens.add_ekran1.add_ekran1 import ADDEkran1
from Automatyzacja.pages.spingo_and_add.add_screens.add_ekran2.add_ekran2 import ADDEkran2
from Automatyzacja.pages.spingo_and_add.add_screens.add_ekran3.add_ekran3 import ADDEkran3
from Automatyzacja.pages.spingo_and_add.add_screens.add_ekran4.add_ekran4 import ADDEkran4
from Automatyzacja.pages.spingo_and_add.common.common_spingo_and_add.common_ekran0.common_ekran_0 import CommonEkran0
from Automatyzacja.pages.spingo_and_add.spingo_and_add_dataclass import SpingoAndAddData


class ADDCommonPath:
    def __init__(self, driver):
        self.driver = driver
        self.ekran0 = CommonEkran0(self.driver)
        self.ekran1 = ADDEkran1(self.driver)
        self.ekran2 = ADDEkran2(self.driver)
        self.ekran3 = ADDEkran3(self.driver)
        self.ekran4 = ADDEkran4(self.driver)
        self.console = ConsoleMain(self.driver)

    def test_add_correct_data(self, data: SpingoAndAddData):
        self.ekran0.fill_and_go_next(data.add_screens_data.ekran0)
        self.ekran1.fill_and_go_next(data.add_screens_data.ekran1)
        self.ekran2.fill_and_go_next()
        self.ekran3.fill_and_go_next(data.add_screens_data.ekran3)
        self.ekran4.fill_and_go_next()
        self.console.fill_and_go_next(data.console_data)

    def test_add_incorrect_data(self, data: SpingoAndAddData):
        self.ekran0.fill_and_go_next(data.add_screens_data.ekran0)
        self.ekran1.fill_and_go_next(data.add_screens_data.ekran1)
        self.ekran2.fill_and_go_next()
        self.ekran3.fill_and_go_next(data.add_screens_data.ekran3)
        self.ekran4.fill_and_go_next()

