from Automatyzacja.pages.console.console_main_page.console import ConsoleMain
from Automatyzacja.pages.spingo_and_add.common.common_spingo_and_add.common_ekran0.common_ekran_0 import CommonEkran0
from Automatyzacja.pages.spingo_and_add.common.common_spingo_and_add.common_ekran1.common_ekran_1 import CommonEkran1
from Automatyzacja.pages.spingo_and_add.common.common_spingo_and_add.common_ekran2.common_ekran_2 import CommonEkran2
from Automatyzacja.pages.spingo_and_add.common.common_spingo_and_add.common_ekran3.common_ekran_3 import CommonEkran3
from Automatyzacja.pages.spingo_and_add.common.common_spingo_and_add.common_ekran4.common_ekran_4 import CommonEkran4
from Automatyzacja.pages.spingo_and_add.spingo_and_add_dataclass import SpingoAndAddData


class ADDCommonPath:
    def __init__(self, driver):
        self.driver = driver
        self.ekran0 = CommonEkran0(self.driver)
        self.ekran1 = CommonEkran1(self.driver)
        self.ekran2 = CommonEkran2(self.driver)
        self.ekran3 = CommonEkran3(self.driver)
        self.ekran4 = CommonEkran4(self.driver)
        self.console = ConsoleMain(self.driver)
